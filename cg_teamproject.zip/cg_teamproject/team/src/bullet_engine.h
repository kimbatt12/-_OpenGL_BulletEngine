#pragma once

#include "cgmath.h"						// using for replace btVector3 with vec3
#include "btBulletDynamicsCommon.h"		// BulletPhysics dynamics header
#include "btBulletCollisionCommon.h"	// BulletPhysics collision header

bool bullet_world_init( btDiscreteDynamicsWorld** pWorld );	// create and initialize dynamics world
bool bullet_add_static_box( vec3 pos, vec3 halfSize );		// create a immovable box
bool bullet_add_dynamic_sphere(vec3 pos, vec3 vel, bool bDynamic);		// create a movable sphere
void bullet_remove_all_dynamic_spheres();
void bullet_update();
bool bullet_cleanup();