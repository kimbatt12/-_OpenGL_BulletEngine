#include "cgmath.h"			// slee's simple math library
#include "cgut2.h"			// slee's OpenGL utility
#include "bullet_engine.h"

#pragma comment( lib, "BulletCollision_vs2013.lib" )
#pragma comment( lib, "BulletDynamics_vs2013.lib" )
#pragma comment( lib, "LinearMath_vs2013.lib" )

#define RESTITUTION 0.8f // elastic constant
#define BALL_RADIUS 5.0f
#define GAME_SPEED	10
//*******************************************************************
// bullet objects
btAlignedObjectArray<btCollisionShape*> collisionShapes;

btDefaultCollisionConfiguration* collisionConfiguration = nullptr;
btCollisionDispatcher* dispatcher = nullptr;
btBroadphaseInterface* overlappingPairCache = nullptr;
btSequentialImpulseConstraintSolver* solver = nullptr;

btDiscreteDynamicsWorld* dynamicsWorld = nullptr;
//*******************************************************************

bool bullet_world_init( btDiscreteDynamicsWorld** pWorld )
{
	if( pWorld==nullptr ) return false;

	// bullet physics engine initialization ------
	collisionConfiguration = new btDefaultCollisionConfiguration();		// collision configuration contains default setup for memory, collision setup.
	if( collisionConfiguration==nullptr ) return false;

	dispatcher = new btCollisionDispatcher( collisionConfiguration );	// collision dispatcher iterates over each pair in Broadphase, searching for a collision between the pair by appropriate algorithms.
	if( dispatcher==nullptr ) return false;

	overlappingPairCache = new btDbvtBroadphase();						// the DbvtBroadphase collision detector uses a fast dynamic bounding volume hierarchy based on AABB tree.
	if( overlappingPairCache==nullptr ) return false;

	solver = new btSequentialImpulseConstraintSolver;					// this solver calculates sequential impulse constraint, so that it can handle sequential instant collisions of multiple objects.
	if( solver==nullptr ) return false;

	dynamicsWorld = new btDiscreteDynamicsWorld( dispatcher, overlappingPairCache, solver, collisionConfiguration );	
	if( dynamicsWorld==nullptr ) return false;

	dynamicsWorld->setGravity( btVector3(0,-9.8f*GAME_SPEED/2.0f,0) );

	*pWorld = dynamicsWorld;

	return true;
}

bool bullet_add_static_box(vec3 pos, vec3 halfSize)
{
	// create a static rigid body.
	btVector3 half_size(halfSize.x,halfSize.y,halfSize.z);
	btCollisionShape* groundShape = new btBoxShape( half_size ); if( groundShape==nullptr ) return false;

	// keep track of the shapes, the engine release memory at exit.
	collisionShapes.push_back( groundShape );

	btTransform groundTransform;
	groundTransform.setIdentity();
	btVector3 position(pos.x,pos.y,pos.z);
	groundTransform.setOrigin( position );
	
	btScalar	mass(0.f);
	btVector3	localInertia(0,0,0);

	btDefaultMotionState* myMotionState = new btDefaultMotionState( groundTransform ); if( myMotionState==nullptr ) return false;
	btRigidBody::btRigidBodyConstructionInfo rbInfo( mass, myMotionState, groundShape, localInertia );
	btRigidBody* body = new btRigidBody( rbInfo ); if( body==nullptr ) return false;
	body->setRestitution( RESTITUTION );

	// add the body to the dynamics world
	dynamicsWorld->addRigidBody( body );
	
	return true;
}

bool bullet_add_dynamic_sphere(vec3 pos, vec3 vel, bool bDynamic)
{
	btCollisionShape* colShape = nullptr;

	// get a dynamic rigidbody if already created
	for( int k=0,kn=collisionShapes.size(); k<kn; k++ )
	{
		// Re-using the same collision is better for memory usage and performance
		// make sure to re-use collision shapes among rigid bodies whenever possible!
		if( collisionShapes[k]->getShapeType() == SPHERE_SHAPE_PROXYTYPE )
			colShape = collisionShapes[k];	
	}

	// otherwise, create one
	if( colShape==nullptr ) 
	{
		colShape = new btSphereShape( BALL_RADIUS );	// radius
		collisionShapes.push_back( colShape );
	}
	if( colShape==nullptr ) return false;

	/// Create Dynamic Objects
	btTransform initialTransform;
	initialTransform.setIdentity();

	//rigidbody is dynamic if and only if mass is non zero, otherwise static
	btScalar	mass;
	if (bDynamic)
		mass = 10.0f;
	else
		mass = 30.0f;
	btVector3 localInertia(0,0,0);
	colShape->calculateLocalInertia(mass,localInertia);

	btVector3 position(pos.x,pos.y,pos.z);
	initialTransform.setOrigin( position );
	
	//using motionstate is recommended, it provides interpolation capabilities, and only synchronizes 'active' objects
	btDefaultMotionState* myMotionState = new btDefaultMotionState(initialTransform); if( myMotionState==nullptr ) return false;
	btRigidBody::btRigidBodyConstructionInfo rbInfo(mass,myMotionState,colShape,localInertia);
	btRigidBody* body = new btRigidBody(rbInfo); if( body==nullptr ) return false;
	body->setRestitution( RESTITUTION );

	if (bDynamic){
		btVector3 velocity(vel.x, vel.y, vel.z);
		body->setLinearVelocity(velocity);
	
		body->applyGravity();
		}

	dynamicsWorld->addRigidBody(body);

	return true;
}

void bullet_remove_all_dynamic_spheres()
{
	for( int i=dynamicsWorld->getNumCollisionObjects()-1; i>=0; i-- )
	{
		btCollisionObject* obj = dynamicsWorld->getCollisionObjectArray()[i];
		btRigidBody* body = btRigidBody::upcast( obj );
		if( body->isStaticObject()==false ) 
		{// we don't have kinetic body yet, so this always means dynamic bodies in this code.
			if( body!=nullptr&&body->getMotionState()!=nullptr )
			{
				delete body->getMotionState();
			}
			dynamicsWorld->removeCollisionObject( obj );
			delete obj;
		}
	}
}

bool bullet_cleanup()
{
	/*cleanup in the reverse order of creation/initialization*/
	
	//remove the rigidbodies from the dynamics world and delete them
	for( int i=dynamicsWorld->getNumCollisionObjects()-1; i>=0; i-- )
	{
		btCollisionObject* obj = dynamicsWorld->getCollisionObjectArray()[i];
		btRigidBody* body = btRigidBody::upcast( obj );
		if( body!=nullptr&&body->getMotionState()!=nullptr )
		{
			delete body->getMotionState();
		}
		dynamicsWorld->removeCollisionObject( obj );
		delete obj;
	}

	//delete collision shapes
	for (int j=0;j<collisionShapes.size();j++)
	{
		btCollisionShape* shape = collisionShapes[j];
		collisionShapes[j] = nullptr;
		delete shape;
	}
		
	delete dynamicsWorld;	
	delete solver;
	delete overlappingPairCache;
	delete dispatcher;
	delete collisionConfiguration;

	//next line is optional: it will be cleared by the destructor when the array goes out of scope
	collisionShapes.clear();

	return true;
}