#include "cgmath.h"			// slee's simple math library
#include "cgut2.h"			// slee's OpenGL utility
#include "assimp_loader.h"
#include "bullet_engine.h"	// bullet physics engine
#include "mesh.h"	// contain mesh create functions and texture load function.
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "irrKlang\irrKlang.h"
#pragma comment(lib, "irrKlang.lib")

#define VELOCITY	60
#define DISTANCEFROMWALL	8
#define DISTANCEFROMGROUND	8
#define SPIKE_RANGE	12
#define GAME_SPEED	10
#define	MAX_SCORE	15
const float ROOT_GAME_SPEED=(float)sqrt(GAME_SPEED);
//*******************************************************************
// global constants
static const char*	window_name = "cg team project";
static const char*	vert_shader_path = "../bin/shaders/transform.vert";
static const char*	frag_shader_path = "../bin/shaders/transform.frag";
static const char*	sea_texture_path = "../bin/mesh/sea.png";
static const char*	box_mesh_vertex_path = "../bin/mesh/box.vertex.bin";
static const char*	box_mesh_index_path = "../bin/mesh/box.index.bin";
static const char*	bounce_sound_path = "../bin/sound/bounce.mp3";
static const char*	spike_sound_path = "../bin/sound/spike.mp3";
static const char*	jump_sound_path = "../bin/sound/jump.mp3";
static const char*	bgm_sound_path = "../bin/sound/bgm.mp3";
static const char*	floor_sound_path = "../bin/sound/floor.mp3";
static const char*	open_sound_path = "../bin/sound/open.mp3";

//*******************************************************************
// common structures
struct camera
{
	vec3	eye = vec3( 100.f, 0.f, 0.f );
	vec3	at = vec3( 0.f, 0.f, 0.f );
	vec3	up = vec3( 0.f, 1.f, 0.f );
	mat4	view_matrix = mat4::lookAt( eye, at, up );
		
	float	fovy = PI/4.0f; // must be in radian
	float	aspect_ratio;
	float	dNear = 1.0f;
	float	dFar = 5000.0f;
	mat4	projection_matrix;
}cam;

//*******************************************************************
// window objects
GLFWwindow*	window = nullptr;
ivec2		window_size = ivec2(1024, 620);	// initial window size
//*******************************************************************
// OpenGL objects
GLuint	program	= 0;	// ID holder for GPU program

//*******************************************************************
// global variables
int		frame = 0;	// index of rendering frames
float	scale = 10;
bool	p1key[6];
bool	p2key[6];
int		p1particle = 0;
int		p2particle = 0;
bool	spike_state = 0;
mat4	ball_pos_reg[60];
int		reg_read_pos=0;
vec3	prtc1pos, prtc2pos;
vec3	p1pos, p2pos, ball_pos;
int		nWalls = 0;
bool	p1AtGround = 1, p2AtGround = 1;
float	p1y = 0.f, p2y = 0.f;
bool	paused = false, regame=false;
int		score[2] = { 0, 0 };
//*******************************************************************
// scene objects
mesh*	circle_mesh = nullptr;
mesh*	box_mesh=nullptr;
mesh*	sphere_mesh = nullptr;
mesh*	square_mesh = nullptr;
mesh*	cube_mesh = nullptr;
mesh*	arena_mesh = nullptr;
mesh*	particle_mesh = nullptr;
mesh*	penguin_mesh = nullptr;
mesh*	cylinder_mesh = nullptr;
GLuint	sea_texture;
camera	cam1, cam2;
mat4	model_matrix[2];
mat4	ball_matrix;
//*******************************************************************
//irrKlang objects
irrklang::ISoundEngine* engine = nullptr;
irrklang::ISoundSource* spike_src = nullptr;
irrklang::ISoundSource* bounce_src = nullptr;
irrklang::ISoundSource* bgm_src = nullptr;
irrklang::ISoundSource* opening_src = nullptr;
irrklang::ISoundSource* jump_src = nullptr;
irrklang::ISoundSource* floor_src = nullptr;
irrklang::ISoundSource* open_src = nullptr;
//*******************************************************************
// bullet objects
// color preset
vec4 WetAsphalt = vec4(52, 73, 94, 255) / 255.f;
vec4 PeterRiver = vec4(52, 152, 219, 255) / 255.f;
vec4 BelizeHole = vec4(41, 128, 185, 255) / 255.f;
vec4 wall_colors[5] = { WetAsphalt, PeterRiver, PeterRiver, BelizeHole, BelizeHole };
btDiscreteDynamicsWorld* bullet_world = nullptr;
std::vector<mat4>	model_matrices;
//*******************************************************************
bool spike(int player_num, vec3 player_pos, btRigidBody* ball);
void bullet_update();
void update();
void bind_buffer(mesh* pMesh);
void draw_particle(vec3 player_pos);
void draw_net();
void render_viewport(uint player);
void render();
void reshape(GLFWwindow* window, int width, int height);
void keyboard(GLFWwindow* window, int key, int scancode, int action, int mods);
void motion(GLFWwindow* window, double x, double y);
void load_texture(const char* texture_path, GLuint* texture_ID);
bool bullet_user_init();
bool user_init();
void user_finalize();
void game_play();
void text_init();
void render_text(std::string text, GLint x, GLint y, GLfloat scale, vec4 color);
void opening_update();
void opening_render();

void game_start(bool p2win){

	//bullet_remove_all_dynamic_spheres();
	bullet_cleanup();
	nWalls = 0;
	bullet_user_init();
	spike_state = 0;
	p1pos = vec3(6.0*SCALE, DISTANCEFROMGROUND, 0.0);
	p2pos = vec3(-6.0*SCALE, DISTANCEFROMGROUND, 0.0);
	bullet_add_dynamic_sphere(p1pos, vec3(0, 0, 0), false);
	model_matrices.push_back(mat4());
	bullet_add_dynamic_sphere(p2pos, vec3(0, 0, 0), false);
	model_matrices.push_back(mat4());
	if (!p2win) bullet_add_dynamic_sphere(vec3(p2pos.x, 70, 0), vec3(0, -1, 0)*BALL_SPEED, true);
	else bullet_add_dynamic_sphere(vec3(p1pos.x, 70, 0), vec3(0, -1, 0)*BALL_SPEED, true);
	model_matrices.push_back(mat4());

	for (frame = 0; !glfwWindowShouldClose(window); frame++)
	{
		glfwPollEvents();	// polling and processing of events
		if (!paused){
			update();			// per-frame update
			render();			// per-frame render
		}
		game_play();
	}
}

void game_play(){//���� �ٴڿ� ������ ���� x��ǥ�� ���ؼ� ���� ������ ������ �ľ�.
	if (ball_pos.y< 8.0f && !paused){
		engine->play2D(floor_src);
		if (ball_pos.x < 0){//p1�� ����
			score[0]++;
			if (score[0] != MAX_SCORE && score[1] != MAX_SCORE)
				game_start(0);
		}
		else if (ball_pos.x > 0){//p2�� ����
			score[1]++;
			if (score[0] != MAX_SCORE && score[1] != MAX_SCORE)
				game_start(1);
		}

		spike_state = 0;


		return;
	}

	if ((score[0] == MAX_SCORE || score[1] == MAX_SCORE) && paused){
		if (regame){
			score[0] = 0; score[1] = 0;
			paused = false;
			regame = false;
			game_start(1);
		}
		/*else{
			user_finalize();
			glfwDestroyWindow(window);
			glfwTerminate();
		}*/
	}
}



void main( int argc, char* argv[] )
{
	// initialization
	if(!glfwInit()){ printf( "[error] failed in glfwInit()\n" ); return; }

	// create window and initialize OpenGL extensions
	if(!(window = cg_create_window( window_name, window_size.x, window_size.y ))){ glfwTerminate(); return; }
	if(!cg_init_extensions( window )){ glfwTerminate(); return; }	// version and extensions

	// initializations and validations
	if(!(program=cg_create_program( vert_shader_path, frag_shader_path ))){ glfwTerminate(); return; }	// create and compile shaders/program
	if(!user_init()){ printf( "Failed to user_init()\n" ); glfwTerminate(); return; }					// user initialization

	// register event callbacks
	glfwSetWindowSizeCallback( window, reshape );	// callback for window resizing events
    glfwSetKeyCallback( window, keyboard );			// callback for keyboard events
	glfwSetCursorPosCallback( window, motion );		// callback for mouse movement
	window_size = ivec2(window_size.x/2, window_size.y);
	// enters rendering/event loop

	engine->play2D(open_src);

	for (frame = 0; !glfwWindowShouldClose(window); frame++)
	{
		glfwPollEvents();	// polling and processing of events
		opening_update();			// per-frame update
		opening_render();			// per-frame render
		if (regame) {
			regame = false;
			break;
		}
	}

	engine->stopAllSounds();
	engine->play2D(bgm_src, true);
	game_start(1);

	
	// normal termination
	user_finalize();
	glfwDestroyWindow(window);
	glfwTerminate();
}

void draw_star(int pos){
	float t = float(glfwGetTime());
	float y = -17.f / t - 17.f;
	if (t < 1) return;
	t = t - (int)t;
	mat4 model_matrix;
	glUniform1i(glGetUniformLocation((program), "particle"), 1);
	bind_buffer(particle_mesh);
	model_matrix = mat4::translate(0.f, y - t*25.f, pos*(3*t+40.f))*mat4::rotate(vec3(0.f, 1.f, 0.f), t*PI*3.5f)*mat4::scale(1.5f, 1.5f, 1.5f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

	model_matrix = mat4::translate(t, y - t*30.f, pos*(-5*t+40.f))*mat4::rotate(vec3(0.f, 1.f, 0.f), t*PI*3.5f)*mat4::scale(1.5f, 1.5f, 1.5f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

	model_matrix = mat4::translate(-2*t, y - t*40.f, pos*(10 * t + 40.f))*mat4::rotate(vec3(0.f, 1.f, 0.f), t*PI*3.5f)*mat4::scale(1.5f, 1.5f, 1.5f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

	model_matrix = mat4::translate(3*t, y - t*50.f, pos*(-13 * t + 40.f))*mat4::rotate(vec3(0.f, 1.f, 0.f), t*PI*3.5f)*mat4::scale(1.5f, 1.5f, 1.5f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

	t = float(glfwGetTime())-0.6f;
	t = t - (int)t;

	model_matrix = mat4::translate(0.f, y - t*25.f, pos*(3 * t + 40.f))*mat4::rotate(vec3(0.f, 1.f, 0.f), t*PI*3.5f)*mat4::scale(1.5f, 1.5f, 1.5f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

	model_matrix = mat4::translate(t, y - t*30.f, pos*(-5 * t + 40.f))*mat4::rotate(vec3(0.f, 1.f, 0.f), t*PI*3.5f)*mat4::scale(1.5f, 1.5f, 1.5f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

	model_matrix = mat4::translate(-2 * t, y - t*40.f, pos*(10 * t + 40.f))*mat4::rotate(vec3(0.f, 1.f, 0.f), t*PI*3.5f)*mat4::scale(1.5f, 1.5f, 1.5f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

	model_matrix = mat4::translate(3 * t, y - t*50.f, pos*(-13 * t + 40.f))*mat4::rotate(vec3(0.f, 1.f, 0.f), t*PI*3.5f)*mat4::scale(1.5f, 1.5f, 1.5f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

	t = float(glfwGetTime()) - 0.3f;
	t = t - (int)t;

	model_matrix = mat4::translate(0.f, y - t*25.f, pos*(3 * t + 40.f))*mat4::rotate(vec3(0.f, 1.f, 0.f), t*PI*3.5f)*mat4::scale(1.5f, 1.5f, 1.5f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

	model_matrix = mat4::translate(t, y - t*30.f, pos*(-5 * t + 40.f))*mat4::rotate(vec3(0.f, 1.f, 0.f), t*PI*3.5f)*mat4::scale(1.5f, 1.5f, 1.5f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

	model_matrix = mat4::translate(-2 * t, y - t*40.f, pos*(10 * t + 40.f))*mat4::rotate(vec3(0.f, 1.f, 0.f), t*PI*3.5f)*mat4::scale(1.5f, 1.5f, 1.5f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

	model_matrix = mat4::translate(3 * t, y - t*50.f, pos*(-13 * t + 40.f))*mat4::rotate(vec3(0.f, 1.f, 0.f), t*PI*3.5f)*mat4::scale(1.5f, 1.5f, 1.5f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);


	glUniform1i(glGetUniformLocation((program), "particle"), 0);
}

void opening_update(){

	glUseProgram(program);
	// update uniform variables in vertex/fragment shaders
	GLint uloc;
	uloc = glGetUniformLocation(program, "view_matrix");			if (uloc>-1) glUniformMatrix4fv(uloc, 1, GL_TRUE, cam.view_matrix);		// update the view matrix (covered later in viewing lecture)
	uloc = glGetUniformLocation(program, "projection_matrix");	if (uloc>-1) glUniformMatrix4fv(uloc, 1, GL_TRUE, cam.projection_matrix);	// update the projection matrix (covered later in viewing lecture)
}			// per-frame update

void opening_render(){
	glUniform1i(glGetUniformLocation(program, "bView"), 1);
	glViewport(0, 0, 2*window_size.x, window_size.y);
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE, 0);
	// clear screen (with background color) and clear depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// notify GL that we use our own program
	glUseProgram(program);

	float t = float(glfwGetTime());
	mat4 model_matrix;
	
	bind_buffer(penguin_mesh);
	model_matrix = mat4::translate(0.f,-17.f/t-8.f,40.f)*mat4::rotate(vec3(0.f,1.f,0.f),t*PI*3.5f)*mat4::scale(3.f, 4.f, 3.f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, penguin_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	draw_star(1);

	bind_buffer(penguin_mesh);
	model_matrix = mat4::translate(0.f, -17.f/t-8.f, -40.f)*mat4::rotate(vec3(0.f, 1.f, 0.f), -t*PI*3.5f)*mat4::scale(3.f, 4.f, 3.f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, penguin_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	draw_star(-1);
	//draw sea
	bind_buffer(cylinder_mesh);
	glUniform1i(glGetUniformLocation(program, "useTEX"), 1);
	// build the model matrix
	model_matrix = mat4::translate(-500.f, 0.f, 0.f)*mat4::rotate(vec3(0.f, 0.f, 1.f), -PI*t / 10.f)*mat4::rotate(vec3(1.f, 0.f, 0.f), PI / 2.f)*mat4::scale(500.f, 500.f, 500.f);
	glActiveTexture(GL_TEXTURE0);								// select the texture slot to bind
	glBindTexture(GL_TEXTURE_2D, sea_texture);
	glUniform1i(glGetUniformLocation(program, "TEX"), 0);	 // GL_TEXTURE0
	// update the uniform model matrix and render
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, cylinder_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	glUniform1i(glGetUniformLocation(program, "useTEX"), 0);
	
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	render_text("WELCOME TO PENGUIN SPIKE!", 100, 200, 0.5f, vec4(1.0f, 1.0f, 1.0f, 1.0f));
	render_text("Press Enter to play", 100, 250, 0.4f, vec4(0.9f, 0.5f, 0.0f, 1-cos(PI*t)));
	render_text("P1 Move : TFGH", 10, window_size.y-150, 0.4f, vec4(0.9f, 0.5f, 0.0f, 1.0f));
	render_text("P2 Move : ^ < v >", window_size.x-190, window_size.y-150, 0.4f, vec4(0.9f, 0.5f, 0.0f, 1.0f));
	render_text("P1 Jump/Spike : A / S", 10, window_size.y - 100, 0.3f, vec4(0.9f, 0.5f, 0.0f, 1.0f));
	render_text("P2 Jump/Spike : [ / ]", window_size.x - 180, window_size.y-100, 0.3f, vec4(0.9f, 0.5f, 0.0f, 1.0f));
	glfwSwapBuffers(window);
	
}			// per-frame render


bool spike(int player_num, vec3 player_pos, btRigidBody* ball){
	vec3 ball_pos = ball->getCenterOfMassPosition();
	vec3 distance = ball_pos - player_pos;
	if (distance.length() < 1.f*SPIKE_RANGE&&!spike_state){
		distance.x += 18 * GAME_SPEED*(player_num - 1.5f);
		distance.z *= GAME_SPEED/1.5f;
		ball->setLinearVelocity(btVector3(distance.x, distance.y, distance.z));
		spike_state = 1;
		return 1;
	}
	return 0;
}
void draw_particle(int player_num, vec3 player_pos){
	if (player_num == 1) {
		p1particle = 1;
		prtc1pos = player_pos;
	}
	else if (player_num == 2) {
		p2particle = 1;
		prtc2pos = player_pos;
	}
}
void bullet_update()
{
	// update simulation
	float t = float(glfwGetTime());
	static float t0 = t;
	float dt = t - t0;
	t0 = t;
	float XMAX = ARENA_SIZE_X*SCALE;
	float ZMAX = ARENA_SIZE_Z*SCALE;
	float xv, zv;
	bullet_world->stepSimulation(dt, 10);

	//print positions of dynamic objects
	for (int j = 0, jn = bullet_world->getNumCollisionObjects(); j<jn; j++)
	{
		// getting collision object to find transform of the object.
		btCollisionObject* obj = bullet_world->getCollisionObjectArray()[j];
		btRigidBody* body = btRigidBody::upcast(obj);
		btTransform trans;
		if (body && body->getMotionState())	body->getMotionState()->getWorldTransform(trans);
		else								trans = obj->getWorldTransform();

		if (j == nWalls){
			btVector3 vel1;
			p1pos = body->getCenterOfMassPosition();
			float x1, x2, z1, z2;
			if (p1key[0])		x1 = -VELOCITY;
			else if (!p1key[0])	x1 = 0;
			if (p1key[1])		x2 = VELOCITY;
			else if (!p1key[1]) x2 = 0;
			if (p1key[2])		z1 = -VELOCITY;
			else if (!p1key[2])	z1 = 0;
			if (p1key[3])		z2 = VELOCITY;
			else if (!p1key[3]) z2 = 0;
			xv = x1 + x2;
			zv = z1 + z2;
			//jump
			if (!p1AtGround) {
				p1y -= GAME_SPEED / 2.0f;
				if (p1pos.y < DISTANCEFROMGROUND){
					p1y = 0.f;
					p1pos.y = DISTANCEFROMGROUND;
					p1AtGround = 1;

				}
			}
			if (!p1key[4] && p1AtGround)   {
				p1y = 0;
			}
			if (p1key[4] && p1AtGround){
				engine->play2D(jump_src);
				p1y = 25.0f*ROOT_GAME_SPEED;
				p1AtGround = 0;
			}


			if (p1pos.x < DISTANCEFROMWALL && xv < 0) xv = 0;
			if (p1pos.x >(XMAX - DISTANCEFROMWALL) && xv > 0) xv = 0;
			if (p1pos.z < (DISTANCEFROMWALL - ZMAX) && zv < 0) zv = 0;
			if (p1pos.z >(ZMAX - DISTANCEFROMWALL) && zv > 0) zv = 0;

			vel1 = btVector3(xv, p1y, zv);
			body->activate();
			body->setLinearVelocity(vel1);
			body->setAngularVelocity(btVector3(0.f, 0.f, 0.f));
		}
		if (j == (nWalls + 1)){
			p2pos = body->getCenterOfMassPosition();
			btVector3 vel2;
			float x1, x2, z1, z2;
			if (p2key[0])		x1 = VELOCITY;
			else if (!p2key[0])	x1 = 0;
			if (p2key[1])		x2 = -VELOCITY;
			else if (!p2key[1]) x2 = 0;
			if (p2key[2])		z1 = VELOCITY;
			else if (!p2key[2])	z1 = 0;
			if (p2key[3])		z2 = -VELOCITY;
			else if (!p2key[3]) z2 = 0;
			xv = x1 + x2;
			zv = z1 + z2;
			//jump
			if (!p2AtGround) {
				p2y -= GAME_SPEED / 2.0f;
				if (p2pos.y < DISTANCEFROMGROUND){
					p2y = 0.f;
					p2pos.y = DISTANCEFROMGROUND;
					p2AtGround = 1;

				}
			}
			if (!p2key[4] && p2AtGround)   {
				p2y = 0;
			}
			if (p2key[4] && p2AtGround){
				engine->play2D(jump_src);
				p2y = 25.0f*ROOT_GAME_SPEED;
				p2AtGround = 0;
			}

			if (p2pos.x > -DISTANCEFROMWALL && xv > 0) xv = 0;
			if (p2pos.x <(DISTANCEFROMWALL - XMAX) && xv < 0) xv = 0;
			if (p2pos.z < (DISTANCEFROMWALL - ZMAX) && zv < 0) zv = 0;
			if (p2pos.z >(ZMAX - DISTANCEFROMWALL) && zv > 0) zv = 0;
			vel2 = btVector3(xv, p2y, zv);
			body->activate();
			body->setLinearVelocity(vel2);
			body->setAngularVelocity(btVector3(0.f, 0.f, 0.f));
		}

		mat4 transform_matrix;
		trans.getOpenGLMatrix(transform_matrix.a); // this OpenGLMatrix uses different major from mat4
		model_matrices[j] = transform_matrix.transpose();


		if (body->isStaticObject())
		{
			btBoxShape* boxShape = (btBoxShape*)body->getCollisionShape();
			btVector3 halfSize = boxShape->getHalfExtentsWithoutMargin();
			model_matrices[j] *= mat4::scale(halfSize.x(), halfSize.y(), halfSize.z());
		}
		else
		{
			btSphereShape* sphereShape = (btSphereShape*)body->getCollisionShape();
			btScalar radius = sphereShape->getRadius();
			model_matrices[j] *= mat4::scale(radius);
			btVector3 curPos = trans.getOrigin();
			ball_pos.x = curPos.x();
			ball_pos.y = curPos.y();
			ball_pos.z = curPos.z();
		}
		//ball_spike
		if (j == (nWalls + 2)){
			static bool contact=false;
			vec3 distance1 = p1pos - (vec3)body->getCenterOfMassPosition();
			vec3 distance2 = p2pos - (vec3)body->getCenterOfMassPosition();			
			if (distance1.length() < 12.0f || distance2.length() < 12.0f)	spike_state = 0;
			if ((distance1.length() < 8.5f || distance2.length() < 8.5f) && (spike_state == 0) && !contact){ engine->play2D(bounce_src); contact = true; }
			if (distance1.length() >= 9.0f && distance2.length() >= 9.0f) contact = false;
			if (p1key[5])	if (spike(1, p1pos, body))	draw_particle(1, p1pos);
			if (p2key[5])	if (spike(2, p2pos, body))	draw_particle(2, p2pos);
			ball_pos_reg[reg_read_pos] = model_matrices[j];
			reg_read_pos++;
			reg_read_pos = reg_read_pos % 60;
		}
	}

}
void update()
{
	glUseProgram(program);
	bullet_update();
	// update uniform variables in vertex/fragment shaders
	GLint uloc;
	uloc = glGetUniformLocation(program, "view_matrix");			if (uloc>-1) glUniformMatrix4fv(uloc, 1, GL_TRUE, cam1.view_matrix);		// update the view matrix (covered later in viewing lecture)
	uloc = glGetUniformLocation(program, "projection_matrix");	if (uloc>-1) glUniformMatrix4fv(uloc, 1, GL_TRUE, cam1.projection_matrix);	// update the projection matrix (covered later in viewing lecture)

	uloc = glGetUniformLocation(program, "view_matrix2");			if (uloc>-1) glUniformMatrix4fv(uloc, 1, GL_TRUE, cam2.view_matrix);		// update the view matrix (covered later in viewing lecture)
	uloc = glGetUniformLocation(program, "projection_matrix2");		if (uloc>-1) glUniformMatrix4fv(uloc, 1, GL_TRUE, cam2.projection_matrix);	// update the projection matrix (covered later in viewing lecture)
}
void bind_buffer(mesh* pMesh)
{
	const char*	vertex_attrib[] = { "position", "normal", "texcoord" };
	size_t		attrib_size[] = { sizeof(vertex().pos), sizeof(vertex().norm), sizeof(vertex().tex) };
	for (size_t k = 0, kn = std::extent<decltype(vertex_attrib)>::value, byte_offset = 0; k<kn; k++, byte_offset += attrib_size[k - 1])
	{
		GLuint loc = glGetAttribLocation(program, vertex_attrib[k]); if (loc >= kn) continue;
		glEnableVertexAttribArray(loc);
		glBindBuffer(GL_ARRAY_BUFFER, pMesh->vertex_buffer);
		glVertexAttribPointer(loc, attrib_size[k] / sizeof(GLfloat), GL_FLOAT, GL_FALSE, sizeof(vertex), (GLvoid*)byte_offset);
	}
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pMesh->index_buffer);
}

void draw_net(){
	//************************************************************************************************
	//net rendering part
//	glBlendFunc(GL_SRC_ALPHA, 1);
	glUniform1i(glGetUniformLocation((program), "net"), 1);
	mat4 model_matrix;
	bind_buffer(cube_mesh);
	// render vertices: trigger shader programs to process vertex data
	model_matrix = mat4::translate(0.f, 1.1f*SCALE, -52.f)*mat4::scale(0.2f, 1.1f*SCALE, 0.2f);
	for (int i = 0; i <= 50; i++){
		model_matrix *= mat4::translate(0.f, 0.f, 10.0f);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
		glDrawElements(GL_TRIANGLES, cube_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	}

	model_matrix = mat4::rotate(vec3(1.f, 0.f, 0.f), PI / 2)*mat4::scale(0.2f, ARENA_SIZE_Z * SCALE, 0.2f);
	for (int i = 0; i <= 10; i++){
		model_matrix = mat4::translate(0.f, 2.0f, 0.f)*model_matrix;
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
		glDrawElements(GL_TRIANGLES, cube_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	}

	glUniform1i(glGetUniformLocation((program), "net"), 0);
}

void render_viewport(uint player){//viewport 0=left-1p, viewport 1=right-2p
	float t = float(glfwGetTime());
	mat4 model_matrix;
	if (player != 1 && player != 0){
		printf("Error!!\n");
		glfwTerminate();
	}
	if (player == 0)	glViewport(0, 0, window_size.x - 1, window_size.y);
	else if (player == 1)	glViewport(window_size.x + 1, 0, window_size.x - 1, window_size.y);
	
	glUseProgram(program);
	//*********************************************************************************************
	//Map rendering part.


	//draw sea
	bind_buffer(cylinder_mesh);
	glUniform1i(glGetUniformLocation(program, "useTEX"), 1);
	// build the model matrix
	model_matrix = mat4::translate(0.f, -1030.f, 0.f)*mat4::rotate(vec3(1.f,0.f,0.f),PI*t/120.f)*mat4::rotate(vec3(0.f, 0.f, 1.f), PI / 2.f)*mat4::scale(1000.f, 1000.f, 1000.f);
	glActiveTexture(GL_TEXTURE0);								// select the texture slot to bind
	glBindTexture(GL_TEXTURE_2D, sea_texture);
	glUniform1i(glGetUniformLocation(program, "TEX"), 0);	 // GL_TEXTURE0

	// update the uniform model matrix and render
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, cylinder_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	glUniform1i(glGetUniformLocation(program, "useTEX"), 0);

	//draw arena
	glUniform1i(glGetUniformLocation(program, "arena"), 1);
	bind_buffer(cylinder_mesh);
	model_matrix = mat4::translate(30.f, -500.f, -10.f)*mat4::rotate(vec3(0.f, 0.f, 1.f), PI / 2.f)*mat4::scale(500.f, 250.f, 500.f);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, cylinder_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	glUniform1i(glGetUniformLocation(program, "arena"), 0);
	//*********************************************************************************************
	draw_net();

	//line
	glUniform1i(glGetUniformLocation(program, "line"), 1);
	bind_buffer(square_mesh);
	model_matrix = mat4::translate(0.f, 1.f, 0.f)*mat4::scale(1.1f, 1.f, ARENA_SIZE_Z*SCALE + 1.f)*mat4::rotate(vec3(0.f, 0.f, 1.f), PI / 2);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, square_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	model_matrix = mat4::translate(ARENA_SIZE_X*SCALE, 1.f, 0.f)*mat4::scale(1.1f,1.f,ARENA_SIZE_Z*SCALE+1.f)*mat4::rotate(vec3(0.f,0.f,1.f),PI/2);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, square_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	model_matrix = mat4::translate(-ARENA_SIZE_X*SCALE, 1.f, 0.f)*mat4::scale(1.1f, 1.f, ARENA_SIZE_Z*SCALE+1.f)*mat4::rotate(vec3(0.f, 0.f, 1.f), PI / 2);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, square_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	model_matrix = mat4::translate(0.f, 1.f, -ARENA_SIZE_Z*SCALE)*mat4::scale(ARENA_SIZE_X*SCALE+1.f, 1.f, 1.1f)*mat4::rotate(vec3(0.f, 0.f, 1.f), PI / 2);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, square_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	model_matrix = mat4::translate(0.f, 1.f, ARENA_SIZE_Z*SCALE)*mat4::scale(ARENA_SIZE_X*SCALE+1.f, 1.f, 1.1f)*mat4::rotate(vec3(0.f, 0.f, 1.f), PI / 2);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, square_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	glUniform1i(glGetUniformLocation(program, "line"), 0);


	bind_buffer(penguin_mesh);
	//player1
	model_matrix = (mat4)model_matrices[nWalls];
	model_matrix= model_matrix* mat4::rotate(vec3(0.f, 1.f, 0.f), PI);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(GL_TRIANGLES, penguin_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	//player2
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrices[nWalls + 1]);
	glDrawElements(GL_TRIANGLES, penguin_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	
	//ball
	bind_buffer(sphere_mesh);
	glUniform1i(glGetUniformLocation(program, "bullet"), 1);
	glUniformMatrix4fv(glGetUniformLocation(program, "bullet_matrix"), 1, GL_TRUE, model_matrices[nWalls + 2]);
	glDrawElements(GL_TRIANGLES, sphere_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	glUniform1i(glGetUniformLocation(program, "bullet"), 0);
	//������ũ �ܻ�
	if (spike_state){
		glUniform1i(glGetUniformLocation((program), "spike"), 1);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, ball_pos_reg[(reg_read_pos+56)%60]);
		glDrawElements(GL_TRIANGLES, sphere_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, ball_pos_reg[(reg_read_pos + 52) % 60]);
		glDrawElements(GL_TRIANGLES, sphere_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, ball_pos_reg[(reg_read_pos + 48) % 60]);
		glDrawElements(GL_TRIANGLES, sphere_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
		glUniform1i(glGetUniformLocation((program), "spike"), 0);
	}
	//ball shadow
	bind_buffer(circle_mesh);
	mat4 tmp_matrix = mat4::translate(ball_pos.x, 1.0f, ball_pos.z)*mat4::scale(vec3(5.0f, 5.0f, 5.0f));
	glUniform1i(glGetUniformLocation(program, "bShadow"), 1);
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, tmp_matrix);
	glDrawElements(GL_TRIANGLES, circle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	//charictor1 shadow
	tmp_matrix = mat4::translate(p1pos.x, 1.0f, p1pos.z)*mat4::scale(vec3(4.0f, 4.0f, 4.0f));
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, tmp_matrix);
	glDrawElements(GL_TRIANGLES, circle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	//charictor2 shadow
	tmp_matrix = mat4::translate(p2pos.x, 1.0f, p2pos.z)*mat4::scale(vec3(4.0f, 4.0f, 4.0f));
	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, tmp_matrix);
	glDrawElements(GL_TRIANGLES, circle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	glUniform1i(glGetUniformLocation(program, "bShadow"), 0);
	//player1 particle
	glUniform1i(glGetUniformLocation(program, "particle"), 1);
	if (p1particle){
		bind_buffer(particle_mesh);
		
		tmp_matrix = mat4::translate(SCALE / 2.f + prtc1pos.x + p1particle/5.f, prtc1pos.y - p1particle*p1particle / 300.f, prtc1pos.z + p1particle / 5.f)*mat4::scale(3.f, 3.f, 3.f);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, tmp_matrix);
		glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
		
		tmp_matrix = mat4::translate(SCALE+prtc1pos.x, prtc1pos.y - p1particle*p1particle / 300.f, prtc1pos.z - p1particle/5.f)*mat4::scale(3.f, 3.f, 3.f);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, tmp_matrix);
		glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

		tmp_matrix = mat4::translate(-SCALE + prtc1pos.x, prtc1pos.y - p1particle*p1particle / 300.f, prtc1pos.z + p1particle / 5.f)*mat4::scale(3.f, 3.f, 3.f);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, tmp_matrix);
		glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

		tmp_matrix = mat4::translate(-SCALE + prtc1pos.x, prtc1pos.y + p1particle/5.f-p1particle*p1particle / 300.f, prtc1pos.z - p1particle / 5.f)*mat4::scale(3.f, 3.f, 3.f);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, tmp_matrix);
		glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

		tmp_matrix = mat4::translate(-SCALE + prtc1pos.x, prtc1pos.y + p1particle / 3.f - p1particle*p1particle /300.f, prtc1pos.z + p1particle / 30.f)*mat4::scale(3.f, 3.f, 3.f);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, tmp_matrix);
		glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);
	
		if (p1particle == 1)
			engine->play2D(spike_src);
		p1particle++;		
		if (p1particle > 40) p1particle = 0;
	}
	//player2 particle
	if (p2particle){
		bind_buffer(particle_mesh);
		tmp_matrix = mat4::translate(SCALE / 2.f + prtc2pos.x + p2particle / 5.f, prtc2pos.y - p2particle*p2particle / 300.f, prtc2pos.z + p2particle / 5.f)*mat4::scale(3.f, 3.f, 3.f);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, tmp_matrix);
		glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

		tmp_matrix = mat4::translate(SCALE + prtc2pos.x, prtc2pos.y - p2particle*p2particle / 300.f, prtc2pos.z - p2particle / 5.f)*mat4::scale(3.f, 3.f, 3.f);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, tmp_matrix);
		glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

		tmp_matrix = mat4::translate(-SCALE + prtc2pos.x, prtc2pos.y - p2particle*p2particle / 300.f, prtc2pos.z + p2particle / 5.f)*mat4::scale(3.f, 3.f, 3.f);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, tmp_matrix);
		glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

		tmp_matrix = mat4::translate(-SCALE + prtc2pos.x, prtc2pos.y + p2particle / 5.f - p2particle*p2particle / 300.f, prtc2pos.z - p2particle / 5.f)*mat4::scale(3.f, 3.f, 3.f);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, tmp_matrix);
		glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

		tmp_matrix = mat4::translate(-SCALE + prtc2pos.x, prtc2pos.y + p2particle / 3.f - p2particle*p2particle / 300.f, prtc2pos.z + p2particle / 30.f)*mat4::scale(3.f, 3.f, 3.f);
		glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, tmp_matrix);
		glDrawElements(GL_TRIANGLES, particle_mesh->index_list.size(), GL_UNSIGNED_INT, nullptr);

		if (p2particle == 1)
			engine->play2D(spike_src);
		p2particle++;		
		if (p2particle > 60) p2particle = 0;
	}
	glUniform1i(glGetUniformLocation(program, "particle"), 0);

	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	if (score[player] == MAX_SCORE){
		render_text("Player" + std::to_string(player + 1) + " Win!!", 100, 200, 1.0f, vec4(0.9f, 0.5f, 0.0f, 1.0f));
		render_text("Press Enter key to play again", 100, window_size.y-100, 0.5f, vec4(0.9f, 0.5f, 0.0f, 0.9f));
		paused = true;
	}
	render_text(std::to_string(score[player]), 100, 100, 1.0f, vec4(0.9f, 0.5f, 0.0f, 1.0f));
}
void render()
{
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE, 0);
	// clear screen (with background color) and clear depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	// notify GL that we use our own program
	glUseProgram(program);
	glUniform1i(glGetUniformLocation(program, "bView"), 0);
	render_viewport(0);
	glUseProgram(program);
	glUniform1i(glGetUniformLocation(program, "bView"), 1);
	render_viewport(1);

	glfwSwapBuffers(window);
}



void reshape(GLFWwindow* window, int width, int height){ window_size = ivec2(width / 2, height); }

void keyboard(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (key == GLFW_KEY_P && action==GLFW_PRESS)//pause
		paused = !paused;
	if (key == GLFW_KEY_ENTER && action == GLFW_PRESS)
		regame = true;
		
	if (key == GLFW_KEY_UP){	//p1 up
		if (action == GLFW_PRESS)			p2key[0] = 1;
		else if (action == GLFW_RELEASE)	p2key[0] = 0;
	}
	if (key == GLFW_KEY_DOWN){	//p1 down
		if (action == GLFW_PRESS)			p2key[1] = 1;
		else if (action == GLFW_RELEASE)	p2key[1] = 0;
	}
	if (key == GLFW_KEY_RIGHT){	//p1 right
		if (action == GLFW_PRESS)			p2key[2] = 1;
		else if (action == GLFW_RELEASE)	p2key[2] = 0;
	}
	if (key == GLFW_KEY_LEFT){	//p1 left
		if (action == GLFW_PRESS)			p2key[3] = 1;
		else if (action == GLFW_RELEASE)	p2key[3] = 0;
	}
	if (key == GLFW_KEY_LEFT_BRACKET){		//p1 jump
		if (action == GLFW_PRESS)			p2key[4] = 1;
		else if (action == GLFW_RELEASE)	p2key[4] = 0;
	}
	if (key == GLFW_KEY_RIGHT_BRACKET){		//p1 smash
		if (action == GLFW_PRESS)			p2key[5] = 1;
		else if (action == GLFW_RELEASE)	p2key[5] = 0;
	}


	if (key == GLFW_KEY_T){		//p2 up
		if (action == GLFW_PRESS)			p1key[0] = 1;
		else if (action == GLFW_RELEASE)	p1key[0] = 0;
	}
	if (key == GLFW_KEY_G){		//p2 down
		if (action == GLFW_PRESS)			p1key[1] = 1;
		else if (action == GLFW_RELEASE)	p1key[1] = 0;
	}
	if (key == GLFW_KEY_H){		//p2 right
		if (action == GLFW_PRESS)			p1key[2] = 1;
		else if (action == GLFW_RELEASE)	p1key[2] = 0;
	}
	if (key == GLFW_KEY_F){		//p2 left
		if (action == GLFW_PRESS)			p1key[3] = 1;
		else if (action == GLFW_RELEASE)	p1key[3] = 0;
	}
	if (key == GLFW_KEY_A){		//p2 jump
		if (action == GLFW_PRESS)			p1key[4] = 1;
		else if (action == GLFW_RELEASE)	p1key[4] = 0;
	}
	if (key == GLFW_KEY_S){		//p2 smash
		if (action == GLFW_PRESS)			p1key[5] = 1;
		else if (action == GLFW_RELEASE)	p1key[5] = 0;
	}
}

void motion(GLFWwindow* window, double x, double y){}
void load_texture(const char* texture_path, GLuint* texture_ID){
	int width, height, comp = 3;
	unsigned char* pimage0 = stbi_load(texture_path, &width, &height, &comp, 3); if (comp == 1) comp = 3; /* convert 1-channel to 3-channel image */
	int stride0 = width*comp, stride1 = (stride0 + 3)&(~3);	// 4-byte aligned stride
	unsigned char* pimage = (unsigned char*)malloc(sizeof(unsigned char)*stride1*height);
	for (int y = 0; y < height; y++) memcpy(pimage + (height - 1 - y)*stride1, pimage0 + y*stride0, stride0); // vertical flip

	// create textures
	glGenTextures(1, texture_ID);
	glBindTexture(GL_TEXTURE_2D, *texture_ID);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8 /* GL_RGB for legacy GL */, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, pimage);

	int mip_levels = get_mip_levels(window_size.x, window_size.y);
	for (int k = 1, w = width >> 1, h = height >> 1; k<mip_levels; k++, w = max(1, w >> 1), h = max(1, h >> 1))
		glTexImage2D(GL_TEXTURE_2D, k, GL_RGB8 /* GL_RGB for legacy GL */, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, nullptr);
	glGenerateMipmap(GL_TEXTURE_2D);
}
bool bullet_user_init()
{
	// create bullet dynamic world
	if (!bullet_world_init(&bullet_world)) return false;

	// create static walls (position, half_size)
	vec3 floorHalfSize = vec3(ARENA_SIZE_X * SCALE, PANE_WIDTH, ARENA_SIZE_Z * SCALE);
	vec3 vWallHalfSize = vec3(ARENA_SIZE_X * 10 * SCALE, ARENA_SIZE_Y * 10 * SCALE, PANE_WIDTH);
	vec3 hWallHalfSize = vec3(PANE_WIDTH, ARENA_SIZE_Y * 10 * SCALE, ARENA_SIZE_Z * 10 * SCALE);

	vec3 floorPos = vec3(0, 0, 0);
	vec3 northWallPos = vec3(0, 0, -ARENA_SIZE_Z * SCALE);// +cameraOffset;
	vec3 southWallPos = vec3(0, 0, ARENA_SIZE_Z * SCALE);// +cameraOffset;
	vec3 westWallPos = vec3(-ARENA_SIZE_X * SCALE, 0, 0);// +cameraOffset;
	vec3 eastWallPos = vec3(ARENA_SIZE_X * SCALE, 0, 0);// +cameraOffset;

	bullet_add_static_box(floorPos, floorHalfSize); nWalls++;
	bullet_add_static_box(northWallPos, vWallHalfSize); nWalls++;
	bullet_add_static_box(southWallPos, vWallHalfSize); nWalls++;
	bullet_add_static_box(westWallPos, hWallHalfSize); nWalls++;
	bullet_add_static_box(eastWallPos, hWallHalfSize); nWalls++;
	bullet_add_static_box(vec3(0, 0, 0), vec3(1.0f, 1.8*SCALE, ARENA_SIZE_Z*SCALE)); nWalls++;
	model_matrices.resize(nWalls);

	return true;
}
bool user_init()
{
	cam.eye = vec3(200.f,0.f,0.f); cam1.at = vec3(0, 0, 0); cam1.up = vec3(0, 1, 0);
	cam.view_matrix = mat4::lookAt(cam1.eye, cam1.at, cam1.up);
	cam.aspect_ratio = (window_size.x) / float(window_size.y);
	cam.projection_matrix = mat4::perspective(cam.fovy, cam.aspect_ratio, cam.dNear, cam.dFar);
	//cam1 initializing
	cam1.eye = vec3(-20 * SCALE, 15 * SCALE, 0); cam1.at = vec3(0, 0, 0); cam1.up = vec3(0, 1, 0);
	cam1.view_matrix = mat4::lookAt(cam1.eye, cam1.at, cam1.up);
	cam1.aspect_ratio = (window_size.x / 2) / float(window_size.y);
	cam1.projection_matrix = mat4::perspective(cam1.fovy, cam1.aspect_ratio, cam1.dNear, cam1.dFar);
	//cam2 initializing
	cam2.eye = vec3(20 * SCALE, 15 * SCALE, 0); cam2.at = vec3(0, 0, 0); cam2.up = vec3(0, 1, 0);
	cam2.view_matrix = mat4::lookAt(cam2.eye, cam2.at, cam2.up);
	cam2.aspect_ratio = (window_size.x / 2) / float(window_size.y);
	cam2.projection_matrix = mat4::perspective(cam2.fovy, cam2.aspect_ratio, cam2.dNear, cam2.dFar);

	//define player's initial position
	p1pos = vec3(6.0*SCALE, DISTANCEFROMGROUND, 0.0);
	p2pos = vec3(-6.0*SCALE, DISTANCEFROMGROUND, 0.0);
	model_matrix[0] = mat4::translate(p1pos);
	model_matrix[1] = mat4::translate(p2pos);
	// init GL states
	glClearColor(39 / 255.0f, 40 / 255.0f, 34 / 255.0f, 1.0f);	// set clear color
	glDisable(GL_CULL_FACE);								// turn on backface culling
	glEnable(GL_DEPTH_TEST);								// turn on depth tests
	glEnable(GL_TEXTURE_2D);

	//load texture
	load_texture(sea_texture_path, &sea_texture);

	box_mesh = cg_load_mesh(box_mesh_vertex_path, box_mesh_index_path);
	if (box_mesh == nullptr){ printf("Unable to load box_mesh\n"); return false; }
	// load the mesh
	arena_mesh = create_arena_mesh();
	sphere_mesh = create_sphere_mesh();
	square_mesh = create_square_mesh();
	cube_mesh = create_cube_mesh();
	circle_mesh = create_circle_mesh();
	particle_mesh = create_particle_mesh();
	penguin_mesh = create_penguin_mesh();
	cylinder_mesh = create_cylinder_mesh();

	engine = irrklang::createIrrKlangDevice();
	if (!engine) return false;
	spike_src = engine->addSoundSourceFromFile(spike_sound_path);
	bounce_src = engine->addSoundSourceFromFile(bounce_sound_path);
	jump_src = engine->addSoundSourceFromFile(jump_sound_path);
	bgm_src = engine->addSoundSourceFromFile(bgm_sound_path);
	floor_src = engine->addSoundSourceFromFile(floor_sound_path);
	open_src = engine->addSoundSourceFromFile(open_sound_path);
	jump_src->setDefaultVolume(0.1f);
	open_src->setDefaultVolume(0.4f);

	bullet_user_init();
	bullet_add_dynamic_sphere(p1pos, vec3(0, 0, 0), false);
	model_matrices.push_back(mat4());
	bullet_add_dynamic_sphere(p2pos, vec3(0, 0, 0), false);
	model_matrices.push_back(mat4());
	bullet_add_dynamic_sphere(vec3(p1pos.x, 70, 0), vec3(0, -1, 0)*BALL_SPEED, true);
	model_matrices.push_back(mat4());
	text_init();
	return true;
}

void user_finalize(){
	bullet_cleanup();
	engine->drop();
}
