#pragma once

#include "cgmath.h"
#include "cgut2.h"

#define SCALE 10
static const float	PANE_WIDTH = 2.0f;
static const float	ARENA_SIZE_X = 10.0f;
static const float	ARENA_SIZE_Z = 5.0f;
static const float	ARENA_SIZE_Y = 5.0f;
static const float	BALL_SPEED = 10.f;

mesh* create_penguin_mesh(){
	mesh* sphere = new mesh();

	sphere->vertex_list.clear();

	// define  vertices
	sphere->vertex_list.push_back({ vec3(1.3f, 1.f, 0.f), vec3(1.f, 0.f, 0.f), vec2(0.9f, 0.f) });
	sphere->vertex_list.push_back({ vec3(0.2f, 1.7f, 0.f), vec3(0.f, 1.f, 1.f), vec2(0.9f, 0.f) });
	sphere->vertex_list.push_back({ vec3(0.2f, 1.f, 0.8f), vec3(0.f, 0.f, 1.f), vec2(0.9f, 0.f) });
	sphere->vertex_list.push_back({ vec3(0.2f, 1.f, -0.8f), vec3(0.f, 0.f, -1.f), vec2(0.9f, 0.f) });

	sphere->vertex_list.push_back({ vec3(-1.3f, -0.9f, 0.f), vec3(1.f, 0.f, 0.f), vec2(0.4f, 0.4f) });
	sphere->vertex_list.push_back({ vec3(0.f, 2.0f, 0.f), vec3(0.f, 1.f, 0.f), vec2(0.4f, 0.4f) });
	sphere->vertex_list.push_back({ vec3(0.f, -0.9f, 1.0f), vec3(0.f, 0.f, 1.f), vec2(0.4f, 0.4f) });
	sphere->vertex_list.push_back({ vec3(0.f, -0.9f, -1.0f), vec3(0.f, 0.f, -1.f), vec2(0.4f, 0.4f) });
	for (uint k = 0; k <= 50; k++)
	{
		float t = PI*0.65f / float(50)*float(k);
		float ct = cos(t), st = sin(t);
		for (uint l = 0; l <= 50; l++)
		{
			float s = PI*2.0f / float(50)*float(l);
			float cs = cos(s), ss = sin(s);
			if (st*cs>0.8f)	sphere->vertex_list.push_back({ vec3(st*cs, 2 * ct, st*ss), vec3(st*cs, ct, st*ss), vec2(0.9f, 0.9f) });
			else sphere->vertex_list.push_back({ vec3(st*cs, 2 * ct, st*ss), vec3(st*cs, ct, st*ss), vec2(0.4f, 0.4f) });
		}
	}


	// clear and create new buffers
	if (sphere->vertex_buffer)	{ glDeleteBuffers(1, &sphere->vertex_buffer);	sphere->vertex_buffer = 0; }
	if (sphere->index_buffer)	{ glDeleteBuffers(1, &sphere->index_buffer);	sphere->index_buffer = 0; }

	// create buffers
	sphere->index_list.clear();
	sphere->index_list.push_back(2); sphere->index_list.push_back(0);	sphere->index_list.push_back(1);
	sphere->index_list.push_back(1); sphere->index_list.push_back(0);	sphere->index_list.push_back(3);
	sphere->index_list.push_back(3); sphere->index_list.push_back(0);	sphere->index_list.push_back(2);

	sphere->index_list.push_back(6); sphere->index_list.push_back(4);	sphere->index_list.push_back(5);
	sphere->index_list.push_back(5); sphere->index_list.push_back(4);	sphere->index_list.push_back(7);
	sphere->index_list.push_back(7); sphere->index_list.push_back(4);	sphere->index_list.push_back(6);
	for (uint k = 7; k <= 2700; k++)
	{
		sphere->index_list.push_back(k);
		sphere->index_list.push_back(k + 51);
		sphere->index_list.push_back(k + 1);
		sphere->index_list.push_back(k + 1);
		sphere->index_list.push_back(k + 51);
		sphere->index_list.push_back(k + 52);
	}

	// generation of vertex buffer: use vertex_list as it is
	glGenBuffers(1, &sphere->vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, sphere->vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex)*sphere->vertex_list.size(), &sphere->vertex_list[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &sphere->index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sphere->index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint)*sphere->index_list.size(), &sphere->index_list[0], GL_STATIC_DRAW);

	return sphere;
}

mesh* create_arena_mesh(){
	mesh* arena = new mesh();
	arena->vertex_list.clear();

	arena->vertex_list.push_back({ vec3(ARENA_SIZE_X * SCALE*2.f, 0, -ARENA_SIZE_Z * SCALE*3.f), vec3(0, 1, 0), vec2(1.0f, 1.0f) });
	arena->vertex_list.push_back({ vec3(-ARENA_SIZE_X * SCALE*2.f, 0, -ARENA_SIZE_Z * SCALE*3.f), vec3(0, 1, 0), vec2(1.0f, 1.0f) });
	arena->vertex_list.push_back({ vec3(-ARENA_SIZE_X * SCALE*2.f, 0, ARENA_SIZE_Z * SCALE*3.f), vec3(0, 1, 0), vec2(1.0f, 1.0f) });
	arena->vertex_list.push_back({ vec3(ARENA_SIZE_X * SCALE*2.f, 0, ARENA_SIZE_Z * SCALE*3.f), vec3(0, 1, 0), vec2(1.0f, 1.0f) });


	if (arena->vertex_buffer)	glDeleteBuffers(1, &arena->vertex_buffer);	arena->vertex_buffer = 0;
	if (arena->index_buffer)	glDeleteBuffers(1, &arena->index_buffer);	arena->index_buffer = 0;
	arena->index_list.clear();

	arena->index_list.push_back(0);
	arena->index_list.push_back(1);
	arena->index_list.push_back(2);

	arena->index_list.push_back(0);
	arena->index_list.push_back(2);
	arena->index_list.push_back(3);


	glGenBuffers(1, &arena->vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, arena->vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex)*arena->vertex_list.size(), &arena->vertex_list[0], GL_STATIC_DRAW);
	// geneation of index buffer
	glGenBuffers(1, &arena->index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, arena->index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint)*arena->index_list.size(), &arena->index_list[0], GL_STATIC_DRAW);

	return arena;
}
mesh* create_circle_mesh(){
	mesh* circle = new mesh();
	circle->vertex_list.clear();

	circle->vertex_list.push_back({ vec3(0, 0, 0), vec3(0.0f, 1.0f, 0.0f), vec2(0.5f) });	// the origin
	for (uint k = 0; k <= 30; k++)
	{
		float angle = PI*2.0f / float(30)*float(k);
		float c = cos(angle), s = sin(angle);
		circle->vertex_list.push_back({ vec3(c, 0.0f, s), vec3(0.0f, 1.0f, 0.0f), vec2(c*0.5f + 0.5f, s*0.5f + 0.5f) });
	}
	if (circle->vertex_buffer)	{ glDeleteBuffers(1, &circle->vertex_buffer);	circle->vertex_buffer = 0; }
	if (circle->index_buffer)	{ glDeleteBuffers(1, &circle->index_buffer);	circle->index_buffer = 0; }

	circle->index_list.clear();
	for (uint k = 0; k < 30; k++)
	{
		circle->index_list.push_back(0);
		circle->index_list.push_back(k + 2);
		circle->index_list.push_back(k + 1);
	}
	glGenBuffers(1, &circle->vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, circle->vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex)*circle->vertex_list.size(), &circle->vertex_list[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &circle->index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, circle->index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint)*circle->index_list.size(), &circle->index_list[0], GL_STATIC_DRAW);
	return circle;
}
mesh* create_cylinder_mesh(){
	mesh* sphere = new mesh();

	sphere->vertex_list.clear();

	// define  vertices
	for (uint k = 0; k <= 30; k++)
	{
		float t = PI*2.0f / float(30)*float(k);
		float ct = cos(t), st = sin(t);
		sphere->vertex_list.push_back({ vec3(ct, 1.f, st), vec3(ct, 0, st), vec2(t/(PI*2.f), 0.f) });
		sphere->vertex_list.push_back({ vec3(ct, -1.f, st), vec3(ct, 0, st), vec2(t/(PI*2.f), 1.f) });
	}

	// clear and create new buffers
	if (sphere->vertex_buffer)	{ glDeleteBuffers(1, &sphere->vertex_buffer);	sphere->vertex_buffer = 0; }
	if (sphere->index_buffer)	{ glDeleteBuffers(1, &sphere->index_buffer);	sphere->index_buffer = 0; }

	// create buffers
	sphere->index_list.clear();
	for (uint k = 0; k <= 59; k++)
	{
		sphere->index_list.push_back(k);
		sphere->index_list.push_back(k + 1);
		sphere->index_list.push_back(k + 2);
		sphere->index_list.push_back(k + 1);
		sphere->index_list.push_back(k + 3);
		sphere->index_list.push_back(k + 2);
	}

	// generation of vertex buffer: use vertex_list as it is
	glGenBuffers(1, &sphere->vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, sphere->vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex)*sphere->vertex_list.size(), &sphere->vertex_list[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &sphere->index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sphere->index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint)*sphere->index_list.size(), &sphere->index_list[0], GL_STATIC_DRAW);

	return sphere;
}
mesh* create_sphere_mesh(){
	mesh* sphere = new mesh();

	sphere->vertex_list.clear();

	// define  vertices
	for (uint k = 0; k <= 30; k++)
	{
		float t = PI*1.0f / float(30)*float(k);
		float ct = cos(t), st = sin(t);
		for (uint l = 0; l <= 30; l++)
		{
			float s = PI*2.0f / float(30)*float(l);
			float cs = cos(s), ss = sin(s);
			sphere->vertex_list.push_back({ vec3(st*cs, st*ss, ct), vec3(st*cs, st*ss, ct), vec2(0.8f, 1.0f) });
		}
	}

	// clear and create new buffers
	if (sphere->vertex_buffer)	{ glDeleteBuffers(1, &sphere->vertex_buffer);	sphere->vertex_buffer = 0; }
	if (sphere->index_buffer)	{ glDeleteBuffers(1, &sphere->index_buffer);	sphere->index_buffer = 0; }

	// create buffers
	sphere->index_list.clear();
	for (uint k = 0; k <= 930; k++)
	{
		sphere->index_list.push_back(k);
		sphere->index_list.push_back(k + 31);
		sphere->index_list.push_back(k + 1);
		sphere->index_list.push_back(k + 1);
		sphere->index_list.push_back(k + 31);
		sphere->index_list.push_back(k + 32);
	}

	// generation of vertex buffer: use vertex_list as it is
	glGenBuffers(1, &sphere->vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, sphere->vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex)*sphere->vertex_list.size(), &sphere->vertex_list[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &sphere->index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sphere->index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint)*sphere->index_list.size(), &sphere->index_list[0], GL_STATIC_DRAW);

	return sphere;
}
mesh* create_square_mesh(){
	mesh* square = new mesh();
	square->vertex_list.clear();

	// define  vertices
	square->vertex_list.push_back({ vec3(0.f, -1.f, 1.f), vec3(-1.f, 0.f, 0.f), vec2(50.f, 242.f) / 255 });
	square->vertex_list.push_back({ vec3(0.f, 1.f, 1.f), vec3(-1.f, 0.f, 0.f), vec2(50.f, 242.f) / 255 });
	square->vertex_list.push_back({ vec3(0.f, -1.f, -1.f), vec3(-1.f, 0.f, 0.f), vec2(50.f, 242.f) / 255 });
	square->vertex_list.push_back({ vec3(0.f, 1.f, -1.f), vec3(-1.f, 0.f, 0.f), vec2(50.f, 242.f) / 255 });

	// clear and create new buffers
	if (square->vertex_buffer)	{ glDeleteBuffers(1, &square->vertex_buffer);	square->vertex_buffer = 0; }
	if (square->index_buffer)	{ glDeleteBuffers(1, &square->index_buffer);	square->index_buffer = 0; }

	// create buffers
	square->index_list.clear();

	square->index_list.push_back(0);
	square->index_list.push_back(2);
	square->index_list.push_back(1);
	square->index_list.push_back(1);
	square->index_list.push_back(2);
	square->index_list.push_back(3);

	square->index_list.push_back(0);
	square->index_list.push_back(1);
	square->index_list.push_back(2);
	square->index_list.push_back(1);
	square->index_list.push_back(3);
	square->index_list.push_back(2);
	// generation of vertex buffer: use vertex_list as it is
	glGenBuffers(1, &square->vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, square->vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex)*square->vertex_list.size(), &square->vertex_list[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &square->index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, square->index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint)*square->index_list.size(), &square->index_list[0], GL_STATIC_DRAW);

	return square;
}
mesh* create_cube_mesh(){
	mesh* cube = new mesh();
	cube->vertex_list.clear();

	cube->vertex_list.push_back({ vec3(0.5f, -1.f, 1.f), vec3(-1.f, 0.f, 0.f), vec2(0.0, 0.0) });
	cube->vertex_list.push_back({ vec3(0.5f, 1.f, 1.f), vec3(-1.f, 0.f, 0.f), vec2(0.0, 0.0) });
	cube->vertex_list.push_back({ vec3(0.5f, -1.f, -1.f), vec3(-1.f, 0.f, 0.f), vec2(0.0, 0.0) });
	cube->vertex_list.push_back({ vec3(0.5f, 1.f, -1.f), vec3(-1.f, 0.f, 0.f), vec2(0.0, 0.0) });

	cube->vertex_list.push_back({ vec3(-0.5f, -1.f, 1.f), vec3(-1.f, 0.f, 0.f), vec2(0.0, 0.0) });
	cube->vertex_list.push_back({ vec3(-0.5f, 1.f, 1.f), vec3(-1.f, 0.f, 0.f), vec2(0.0, 0.0) });
	cube->vertex_list.push_back({ vec3(-0.5f, -1.f, -1.f), vec3(-1.f, 0.f, 0.f), vec2(0.0, 0.0) });
	cube->vertex_list.push_back({ vec3(-0.5f, 1.f, -1.f), vec3(-1.f, 0.f, 0.f), vec2(0.0, 0.0) });


	// clear and create new buffers
	if (cube->vertex_buffer)	{ glDeleteBuffers(1, &cube->vertex_buffer);	cube->vertex_buffer = 0; }
	if (cube->index_buffer)	{ glDeleteBuffers(1, &cube->index_buffer);	cube->index_buffer = 0; }

	// create buffers
	cube->index_list.clear();

	cube->index_list.push_back(0); cube->index_list.push_back(2); cube->index_list.push_back(1);
	cube->index_list.push_back(1); cube->index_list.push_back(2); cube->index_list.push_back(3);

	cube->index_list.push_back(1); cube->index_list.push_back(3); cube->index_list.push_back(5);
	cube->index_list.push_back(5); cube->index_list.push_back(3); cube->index_list.push_back(7);

	cube->index_list.push_back(0); cube->index_list.push_back(4); cube->index_list.push_back(2);
	cube->index_list.push_back(2); cube->index_list.push_back(4); cube->index_list.push_back(6);

	cube->index_list.push_back(1); cube->index_list.push_back(5); cube->index_list.push_back(4);
	cube->index_list.push_back(0); cube->index_list.push_back(1); cube->index_list.push_back(4);

	cube->index_list.push_back(6); cube->index_list.push_back(3); cube->index_list.push_back(2);
	cube->index_list.push_back(6); cube->index_list.push_back(7); cube->index_list.push_back(3);

	cube->index_list.push_back(4); cube->index_list.push_back(5); cube->index_list.push_back(7);
	cube->index_list.push_back(4); cube->index_list.push_back(7); cube->index_list.push_back(6);


	// generation of vertex buffer: use vertex_list as it is
	glGenBuffers(1, &cube->vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, cube->vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex)*cube->vertex_list.size(), &cube->vertex_list[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &cube->index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cube->index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint)*cube->index_list.size(), &cube->index_list[0], GL_STATIC_DRAW);

	return cube;
}

mesh* create_particle_mesh(){
	mesh* particle = new mesh();
	particle->vertex_list.clear();

	particle->vertex_list.push_back({ vec3(0.5f, 0.f, 0.f), vec3(1.f, 0.f, 0.f), vec2(1.f, 1.f) });
	particle->vertex_list.push_back({ vec3(-0.5f, 0.f, 0.f), vec3(-1.f, 0.f, 0.f), vec2(1.f, 1.f) });
	particle->vertex_list.push_back({ vec3(0.f, 0.5f, 0.f), vec3(0.f, 1.f, 0.f), vec2(1.f, 1.f) });
	particle->vertex_list.push_back({ vec3(0.f, -0.5f, 0.f), vec3(0.f, -1.f, 0.f), vec2(1.f, 1.f) });
	particle->vertex_list.push_back({ vec3(0.0f, 0.f, 0.5f), vec3(0.f, 0.f, 1.f), vec2(1.f, 1.f) });
	particle->vertex_list.push_back({ vec3(0.0f, 0.f, -0.5f), vec3(0.f, 0.f, -1.f), vec2(1.f, 1.f) });

	particle->vertex_list.push_back({ vec3(1.0f, 0.f, 0.f), vec3(1.f, 0.f, 0.f), vec2(1.f, 1.f) });
	particle->vertex_list.push_back({ vec3(-1.f, 0.f, 0.f), vec3(-1.f, 0.f, 0.f), vec2(1.f, 1.f) });
	particle->vertex_list.push_back({ vec3(0.f, 1.f, 0.f), vec3(0.f, 1.f, 0.f), vec2(1.f, 1.f) });
	particle->vertex_list.push_back({ vec3(0.f, -1.f, 0.f), vec3(0.f, -1.f, 0.f), vec2(1.f, 1.f) });
	particle->vertex_list.push_back({ vec3(0.0f, 0.f, 1.f), vec3(0.f, 0.f, 1.f), vec2(1.f, 1.f) });
	particle->vertex_list.push_back({ vec3(0.0f, 0.f, -1.f), vec3(0.f, 0.f, -1.f), vec2(1.f, 1.f) });
	// clear and create new buffers
	if (particle->vertex_buffer)	{ glDeleteBuffers(1, &particle->vertex_buffer);	particle->vertex_buffer = 0; }
	if (particle->index_buffer)	{ glDeleteBuffers(1, &particle->index_buffer);	particle->index_buffer = 0; }

	// create buffers
	particle->index_list.clear();

	particle->index_list.push_back(0); particle->index_list.push_back(10); particle->index_list.push_back(2);
	particle->index_list.push_back(2); particle->index_list.push_back(10); particle->index_list.push_back(1);
	particle->index_list.push_back(1); particle->index_list.push_back(10); particle->index_list.push_back(3);
	particle->index_list.push_back(0); particle->index_list.push_back(10); particle->index_list.push_back(2);
	particle->index_list.push_back(3); particle->index_list.push_back(10); particle->index_list.push_back(0);

	particle->index_list.push_back(2); particle->index_list.push_back(11); particle->index_list.push_back(0);
	particle->index_list.push_back(0); particle->index_list.push_back(11); particle->index_list.push_back(3);
	particle->index_list.push_back(3); particle->index_list.push_back(11); particle->index_list.push_back(1);
	particle->index_list.push_back(1); particle->index_list.push_back(11); particle->index_list.push_back(2);

	particle->index_list.push_back(2); particle->index_list.push_back(6); particle->index_list.push_back(4);
	particle->index_list.push_back(4); particle->index_list.push_back(6); particle->index_list.push_back(3);
	particle->index_list.push_back(3); particle->index_list.push_back(6); particle->index_list.push_back(5);
	particle->index_list.push_back(5); particle->index_list.push_back(6); particle->index_list.push_back(2);

	particle->index_list.push_back(4); particle->index_list.push_back(7); particle->index_list.push_back(2);
	particle->index_list.push_back(2); particle->index_list.push_back(7); particle->index_list.push_back(5);
	particle->index_list.push_back(5); particle->index_list.push_back(7); particle->index_list.push_back(3);
	particle->index_list.push_back(3); particle->index_list.push_back(7); particle->index_list.push_back(4);
	
	particle->index_list.push_back(0); particle->index_list.push_back(8); particle->index_list.push_back(5);
	particle->index_list.push_back(5); particle->index_list.push_back(8); particle->index_list.push_back(1);
	particle->index_list.push_back(1); particle->index_list.push_back(8); particle->index_list.push_back(4);
	particle->index_list.push_back(4); particle->index_list.push_back(8); particle->index_list.push_back(0);

	particle->index_list.push_back(5); particle->index_list.push_back(9); particle->index_list.push_back(0);
	particle->index_list.push_back(0); particle->index_list.push_back(9); particle->index_list.push_back(4);
	particle->index_list.push_back(4); particle->index_list.push_back(9); particle->index_list.push_back(1);
	particle->index_list.push_back(1); particle->index_list.push_back(9); particle->index_list.push_back(5);
	// generation of vertex buffer: use vertex_list as it is
	glGenBuffers(1, &particle->vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, particle->vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex)*particle->vertex_list.size(), &particle->vertex_list[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &particle->index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, particle->index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint)*particle->index_list.size(), &particle->index_list[0], GL_STATIC_DRAW);

	return particle;
}
