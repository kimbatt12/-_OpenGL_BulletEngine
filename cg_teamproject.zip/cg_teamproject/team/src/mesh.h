#pragma once

#include "cgmath.h"
#include "cgut2.h"

#define SCALE 10
static const float	PANE_WIDTH = 2.0f;
static const float	ARENA_SIZE_X = 10.0f;
static const float	ARENA_SIZE_Z = 5.0f;
static const float	ARENA_SIZE_Y = 5.0f;
static const float	BALL_SPEED = 10.f;

mesh* create_sphere_mesh();
mesh* create_arena_mesh();
mesh* create_circle_mesh();
mesh* create_square_mesh();
mesh* create_cube_mesh();
mesh* create_particle_mesh();
mesh* create_penguin_mesh();
mesh* create_cylinder_mesh();
